steal
 .plugins("jquery/dom/fixture")  //load your app
 .plugins('funcunit/qunit')  //load qunit
 .then("fixture_test")