/**
 * @page specialevents Special Events
 * @tag core
 * JavaScriptMVC adds a bunch of useful jQuery extensions for the dom.  Check them out on the left.
 */
steal.plugins('jquery');