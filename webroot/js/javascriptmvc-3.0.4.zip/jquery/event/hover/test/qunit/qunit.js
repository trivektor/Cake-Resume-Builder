steal
 .plugins("jquery/event/hover",'funcunit/synthetic')  //load your app
 .plugins('funcunit/qunit')  //load qunit
 .then("hover_test")