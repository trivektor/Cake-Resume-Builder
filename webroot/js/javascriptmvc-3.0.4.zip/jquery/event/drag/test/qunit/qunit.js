steal
 .plugins("jquery/event/drop",'funcunit/synthetic')  //load your app
 .plugins('funcunit/qunit' )  //load qunit
 .then("drag_test")