// loads all of jquerymx's command line tests

load('jquery/view/test/compression/run.js');

load("jquery/generate/test/run.js");

