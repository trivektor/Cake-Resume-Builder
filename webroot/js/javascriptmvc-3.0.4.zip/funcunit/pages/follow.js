/**
 * @page follow Follow FuncUnit
 * <h1 class='addFavorite'>Following FuncUnit</h1>
 * <h2>Twitter</h2>
<a href='http://twitter.com/funcunit' class='floatLeft'>
    <img src='http://wiki.javascriptmvc.com/wiki/images/f/f7/Twitter.png' class='noborder'/>
</a>

 * Follow [http://twitter.com/funcunit @funcunit] on twitter for daily useful tips.
 * <h2 class='spaced'>Blog</h2>
<a href='http://jupiterit.com/' class='floatLeft'>
    <img src='http://wiki.javascriptmvc.com/wiki/images/e/e5/Blog.png' class='noborder'/>
</a>

 * Read [http://jupiterit.com/ JavaScriptMVC's Blog] for articles, techniques and ideas
 * on maintainable JavaScript.
 * <h2 class='spaced'>Email List</h2>

<a href='http://forum.javascriptmvc.com/#Forum/funcunit' class='floatLeft'>
    <img src='http://wiki.javascriptmvc.com/wiki/images/8/84/Discuss.png' class='noborder'/>
</a>
 * Discuss ideas to make the project better or problems you are having on  [http://forum.javascriptmvc.com/#Forum/funcunit FuncUnit's Forum] 
 * .
 */
//