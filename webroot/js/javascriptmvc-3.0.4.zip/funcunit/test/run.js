//integration point for JavaScriptMVC testing

print("==========================  funcunit ============================")

load('steal/rhino/steal.js');
load('funcunit/loader.js');
FuncUnit.load('funcunit/funcunit.html');