//we probably have to have this only describing where the tests are
steal
 .plugins("funcunit/synthetic/test/qunit")