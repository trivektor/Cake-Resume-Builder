steal
 .plugins("funcunit")
 .then("funcunit_test",
 "find_closest_test",
 "open_test",
 "syn_test",
 'protodrag_test')