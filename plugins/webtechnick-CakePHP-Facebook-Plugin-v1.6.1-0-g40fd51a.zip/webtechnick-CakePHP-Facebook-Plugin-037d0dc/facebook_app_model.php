<?php
App::import('Lib', 'Facebook.FacebookInfo');
class FacebookAppModel extends AppModel {

}

?>